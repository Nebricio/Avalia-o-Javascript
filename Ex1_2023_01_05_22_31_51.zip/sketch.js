for(let i = 0; i < 100; i++){
  
  let a = i+1;
  
  if((i+1)%3 == 0){
     a ="Fizz";
       
  }
   
   if((i+1)%5 == 0){
      if(a == "Fizz")
        a = "FizzBuzz";
      
      else{
        a = "Buzz"
      }
    }
  
      console.log(a);
  
}