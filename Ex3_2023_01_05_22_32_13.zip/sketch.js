//produto mais caro

let aa = [
  { produto: "geladeira", categoria: "eletrodomestico", valor: 1432.67}, 
  { produto: "fogao", categoria: "eletrodomestico", valor: 852.11}, 
  { produto: "microondas", categoria: "eletrodomestico", valor: 933.42}, 
  { produto: "liquidificador", categoria: "eletrodomestico", valor: 187.24}, 
  { produto: "xiaomi", categoria: "smartphone", valor: 1375.66}, 
  { produto: "iphone", categoria: "smartphone", valor: 8432.92}, 
  { produto: "samsung", categoria: "smartphone", valor: 4221.44}, 
  { produto: "Ig", categoria: "smartphone", valor: 1224.88}, 
  { produto: "sofa", categoria: "moveis", valor: 3745.61}, 
  { produto: "mesa", categoria: "moveis", valor: 3111.82}, 
  {produto: "cadeira", categoria: "moveis", valor: 329.41}
  ]


let ecaro = 0, scaro = 0, mcaro = 0;
let enome, snome, mnome;

for(let i = 0; i < aa.length; i++){
  if (aa[i].categoria == "eletrodomestico"){
    if (aa[i].valor > ecaro){
    ecaro = aa[i].valor;
    enome = aa[i].produto;
    }
  }
  
  if (aa[i].categoria == "smartphone"){
    if (aa[i].valor > scaro){
    scaro = aa[i].valor;
    snome = aa[i].produto;
    }
  }
  
  if (aa[i].categoria == "moveis"){
    if (aa[i].valor > mcaro){
    mcaro = aa[i].valor;
    mnome = aa[i].produto;
    }
  }
  
  
  
}

console.log("eletrodomestico mais caro: " + enome + " R$"+ ecaro);
console.log("smartphone mais caro: " + snome + " R$"+ scaro);
console.log("movel mais caro: " + mnome + " R$"+ mcaro);