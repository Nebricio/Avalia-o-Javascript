let desc = 0;

let aa = [
  { produto: "geladeira", categoria: "eletrodomestico", valor: 1432.67}, 
  { produto: "fogao", categoria: "eletrodomestico", valor: 852.11}, 
  { produto: "microondas", categoria: "eletrodomestico", valor: 933.42}, 
  { produto: "liquidificador", categoria: "eletrodomestico", valor: 187.24}, 
  { produto: "xiaomi", categoria: "smartphone", valor: 1375.66}, 
  { produto: "iphone", categoria: "smartphone", valor: 8432.92}, 
  { produto: "samsung", categoria: "smartphone", valor: 4221.44}, 
  { produto: "Ig", categoria: "smartphone", valor: 1224.88}, 
  { produto: "sofa", categoria: "moveis", valor: 3745.61}, 
  { produto: "mesa", categoria: "moveis", valor: 3111.82}, 
  {produto: "cadeira", categoria: "moveis", valor: 329.41}
  ];

for(let i = 0; i < aa.length; i++){
  if(aa[i].categoria == "eletrodomestico"){
    if(aa[i].valor > 1000){
      desc = aa[i].valor * 0.10;
    }else if(aa[i].valor > 500){
      desc = aa[i].valor * 0.07;
    }else{
      desc = aa[i].valor * 0.05;
    }
    
    aa[i].valor = aa[i].valor - desc;
    
    console.log(aa[i].produto, aa[i].categoria, aa[i].valor.toFixed(2));
  }
}