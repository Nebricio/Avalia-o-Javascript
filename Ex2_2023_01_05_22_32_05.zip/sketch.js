function setup() {
  let i = 0;
  
  while(i < 60){
     setInterval(printNow,1000);
  i++;
    
  }
}

function printNow(){
  console.log(hour() +':'+ minute() +':' + second());
}