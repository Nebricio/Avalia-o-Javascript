//Ex5

let elet = 0, smart = 0, mov = 0;
let selet = 0, medelet = 0, ssmart = 0, msmart = 0, smov = 0, mmov = 0;


let aa = [
  { produto: "geladeira", categoria: "eletrodomestico", valor: 1432.67}, 
  { produto: "fogao", categoria: "eletrodomestico", valor: 852.11}, 
  { produto: "microondas", categoria: "eletrodomestico", valor: 933.42}, 
  { produto: "liquidificador", categoria: "eletrodomestico", valor: 187.24}, 
  { produto: "xiaomi", categoria: "smartphone", valor: 1375.66}, 
  { produto: "iphone", categoria: "smartphone", valor: 8432.92}, 
  { produto: "samsung", categoria: "smartphone", valor: 4221.44}, 
  { produto: "Ig", categoria: "smartphone", valor: 1224.88}, 
  { produto: "sofa", categoria: "moveis", valor: 3745.61}, 
  { produto: "mesa", categoria: "moveis", valor: 3111.82}, 
  {produto: "cadeira", categoria: "moveis", valor: 329.41}
  ]

for(let i = 0; i < aa.length; i++){
  
  if(aa[i].categoria == "eletrodomestico"){
    elet ++;
    selet = selet + aa[i].valor;
  }else if(aa[i].categoria == "smartphone"){
    smart ++;
    ssmart = ssmart + aa[i].valor;
  }else{
    mov ++;
    smov = smov + aa[i].valor;
  }  
  
}

console.log("eletrodoméstico: R$ "+ (selet/elet).toFixed(2));
console.log("smartphone: R$ "+ (ssmart/smart).toFixed(2));
console.log("móveis: R$ " + (smov/mov).toFixed(2));